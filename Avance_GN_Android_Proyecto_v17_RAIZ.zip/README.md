# Avance G-N — Aplicación Android

Aplicación Android para ejecutar sin conexión el examen de práctica de opción múltiple integrado en `app/src/main/assets/index.html`.

## Compilar APK

1. Sube el contenido de esta carpeta a la raíz del repositorio de GitHub (no subas la carpeta contenedora como un subdirectorio).
2. Abre **Actions** y selecciona **Build Avance G-N APK**.
3. Pulsa **Run workflow** y espera a que termine correctamente.
4. En la ejecución, descarga el artefacto **Avance-GN-debug-APK**. Dentro estará `app-debug.apk`.

El APK de depuración sirve para instalar y probar en Android. No es una publicación firmada para Play Store.

## Funciones
- 100 reactivos de opción múltiple, con selección de 10, 25, 50 o 100.
- Orden aleatorio de preguntas y opciones.
- Modo examen y modo estudio.
- Calificación, revisión, repaso de errores e historial local.
- Persistencia local y uso sin conexión.

**Nota de contenido:** los reactivos y sus fundamentos deben cotejarse individualmente con las fuentes oficiales vigentes antes de usarse como material oficial de preparación.
