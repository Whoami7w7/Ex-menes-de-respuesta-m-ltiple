package mx.avancegn.examen;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidDownload(), "AndroidDownload");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidDownload {
        @JavascriptInterface public void saveText(String filename, String content) {
            runOnUiThread(() -> {
                try {
                    File out = new File(getCacheDir(), filename.replaceAll("[^A-Za-z0-9._-]", "_"));
                    try (FileOutputStream stream = new FileOutputStream(out)) {
                        stream.write(content.getBytes(StandardCharsets.UTF_8));
                    }
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(out));
                    share.putExtra(Intent.EXTRA_SUBJECT, "Resultado del examen Avance G-N");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    // Send plain text as well, so the result can be copied or saved in another app.
                    share.putExtra(Intent.EXTRA_TEXT, content);
                    startActivity(Intent.createChooser(share, "Guardar o compartir resultado"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo preparar el archivo de resultados", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
